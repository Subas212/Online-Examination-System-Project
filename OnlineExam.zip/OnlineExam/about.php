<!DOCTYPE html>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>Subas</title>
	<link rel="stylesheet" href="css/style.css"/>
</head>
<body>
<div id="container">

	<div id="signature">
		<div id="pic">
		    <img id="img" src="img/Subas.jpg"/>
		</div>
		<div id="description">
			<h2>Subas Chandra Roy</h2>
			<h4>
				<li>Atgaon,Setabganj - 5216</li>
				<li>Bochaganj, Dinajpur. </li>				 
				<li><a href="subasroy212@gmail.com" target="_blank">subasroy212@gmail.com </a></li>
				<li><a href="callto:01737174979">+8801737174979</a></li>
		 </h4>
		</div>
	</div>

	<div id="main">
	 <div>	
  		<div id="headline1"><b>Career Objective</b></div>  
  		<div id="text"> <p>I want to be a well-skilled Web-Developer. </p>
  		</div>
     </div>
        <div>
  			<div id="headline"><b>Academic Qualification</b></div>
            <div>
  				<table id ="table" border="1">
  				<tr>
  					<td>
  						Sl.
  					</td>
  					<td>
  						Degree Name
  					</td>
  					<td>
  						Institution Name
  					</td>
  					<td>
  						Board
  					</td>
  					<td>
  						Department
  					</td>
  					<td>
  						Result
  					</td>
  					<td>
  						Passing Year
  					</td>
  				</tr>
  				<tr>
  					<td>
  						1.
  					</td>
  					<td>
  						Diploma
  					</td>
  					<td>
  						Dinajpur Polytechnic Institute
  					</td>
  					<td>
  						Technical Board
  					</td>
  					<td>
  						Computer
  					</td>
  					<td>
  						---
  					</td>
  					<td>
  						Final Running
  					</td>
  				</tr>
  				<tr>
  					<td>
  						2.
  					</td>
  					<td>
  						SSC
  					</td>
  					<td>
  						Atgaon High School
  					</td>
  					<td>
  						Dinajpur Board
  					</td>
  					<td>
  						Science
  					</td>
  					<td>
  						5.00
  					</td>
  					<td>
  						2014
  					</td>
  				</tr>
  			</table>

            </div>

  			</div>

		<div>
  			<div id="headline3"><b>Training Summary</b></div>
			 <div>
  				<table id ="table2" border="1">
  				<tr>
  					<td>
  						Time
  					</td>
  					<td>
  						Institute
  					</td>
  				</tr>
  				<tr>
  					<td>Oct 2016-Dec 2016</td>
  					<td>Learning and Earning Development Project ICT Division,Bangladesh </td>
  				</tr>
  			</table>

              </div>

  			</div>
	   <div>		
  		<div id="headline4"><b>Strength</b></div>
		 <div id="text3" border="1">
		    <ul>
			   <li>Good leadership skill.</li>
  				<li>Creative thinking and hard working.</li>
  				<li>Self motivated and strong concern for career.</li>
				</ul>
			</div>
  		 </div>
		<div>
  			<div id="headline5"><b>Declaration</b></div>
  			<div id="text"></br>
			I hereby, declare that the above information in the resume is true and correct to the
best of my knowledge and behalf.

  		</div>
	   </div>
	
	</div>
</div>
</body>
</html>